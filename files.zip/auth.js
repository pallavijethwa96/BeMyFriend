const express = require("express");
const { query, getClient } = require("../db");
const config = require("../config");
const {
  signAccessToken, newRefreshToken, sha256, refreshExpiry,
  generateOtp, hashOtp, verifyOtp, otpExpiry, requireAuth,
} = require("../auth");

const router = express.Router();

const emailRe = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Shape the user object returned to clients (no internal fields).
function publicUser(u) {
  return {
    id: u.id,
    displayName: u.display_name,
    anonDefault: u.anon_default,
    country: u.country,
    onboarded: !!u.onboarded_at,
    isStaff: !!u.is_staff,
  };
}

// POST /auth/start  { email, phone } -> { challengeId }
router.post("/auth/start", async (req, res, next) => {
  try {
    const email = (req.body.email || "").trim().toLowerCase();
    const phone = (req.body.phone || "").trim();
    if (!emailRe.test(email)) return res.status(422).json({ error: { code: "bad_email", message: "Enter a valid email." } });
    if (phone.replace(/\D/g, "").length < 6) return res.status(422).json({ error: { code: "bad_phone", message: "Enter a valid phone number." } });

    // Find or create a pending user keyed by email (or phone).
    let { rows } = await query(
      `SELECT * FROM users WHERE deleted_at IS NULL AND (lower(email) = $1 OR phone = $2) LIMIT 1`,
      [email, phone]
    );
    let user = rows[0];
    if (!user) {
      ({ rows } = await query(
        `INSERT INTO users (email, phone) VALUES ($1, $2) RETURNING *`,
        [email, phone]
      ));
      user = rows[0];
    }

    const challengeId = require("crypto").randomUUID();
    const code = generateOtp();
    const codeHash = await hashOtp(code);
    await query(
      `INSERT INTO verification_codes (challenge_id, user_id, channel, destination, code_hash, expires_at)
       VALUES ($1, $2, 'email', $3, $4, $5)`,
      [challengeId, user.id, email, codeHash, otpExpiry()]
    );

    // TODO: send `code` via your email + SMS providers (same code to both).
    if (config.env !== "production") console.log(`[DEV OTP] ${email} / ${phone} -> ${code}`);

    res.json({
      challengeId,
      expiresInSec: config.otpTtlMin * 60,
      // In non-production we return the code so you can test without a provider.
      ...(config.env !== "production" ? { devCode: code } : {}),
    });
  } catch (e) { next(e); }
});

// POST /auth/verify  { challengeId, code } -> { accessToken, refreshToken, user, isNewUser }
router.post("/auth/verify", async (req, res, next) => {
  try {
    const { challengeId, code } = req.body;
    if (!challengeId || !code) return res.status(422).json({ error: { code: "missing", message: "challengeId and code are required." } });

    const { rows } = await query(
      `SELECT * FROM verification_codes
       WHERE challenge_id = $1 AND consumed_at IS NULL
       ORDER BY created_at DESC LIMIT 1`,
      [challengeId]
    );
    const vc = rows[0];
    if (!vc) return res.status(400).json({ error: { code: "no_challenge", message: "Code not found. Request a new one." } });
    if (new Date(vc.expires_at) < new Date()) return res.status(400).json({ error: { code: "expired", message: "Code expired. Request a new one." } });
    if (vc.attempts >= config.otpMaxAttempts) return res.status(429).json({ error: { code: "too_many", message: "Too many attempts. Request a new code." } });

    const ok = await verifyOtp(String(code), vc.code_hash);
    if (!ok) {
      await query(`UPDATE verification_codes SET attempts = attempts + 1 WHERE id = $1`, [vc.id]);
      return res.status(401).json({ error: { code: "bad_code", message: "That code doesn't match." } });
    }

    await query(`UPDATE verification_codes SET consumed_at = now() WHERE id = $1`, [vc.id]);

    const userRes = await query(
      `UPDATE users SET email_verified_at = COALESCE(email_verified_at, now()),
                        phone_verified_at = COALESCE(phone_verified_at, now())
       WHERE id = $1 RETURNING *`,
      [vc.user_id]
    );
    const user = userRes.rows[0];

    const { token: refreshToken, hash } = newRefreshToken();
    await query(
      `INSERT INTO auth_sessions (user_id, refresh_token_hash, user_agent, ip, expires_at)
       VALUES ($1, $2, $3, $4, $5)`,
      [user.id, hash, req.headers["user-agent"] || null, req.ip, refreshExpiry()]
    );

    res.json({
      accessToken: signAccessToken(user),
      refreshToken,
      user: publicUser(user),
      isNewUser: !user.onboarded_at,
    });
  } catch (e) { next(e); }
});

// POST /auth/refresh  { refreshToken } -> rotated tokens
router.post("/auth/refresh", async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(422).json({ error: { code: "missing", message: "refreshToken required." } });
    const hash = sha256(refreshToken);

    const client = await getClient();
    try {
      await client.query("BEGIN");
      const { rows } = await client.query(
        `SELECT * FROM auth_sessions WHERE refresh_token_hash = $1 AND revoked_at IS NULL AND expires_at > now() FOR UPDATE`,
        [hash]
      );
      const session = rows[0];
      if (!session) { await client.query("ROLLBACK"); return res.status(401).json({ error: { code: "bad_refresh", message: "Please sign in again." } }); }

      // rotate: revoke old, issue new
      await client.query(`UPDATE auth_sessions SET revoked_at = now() WHERE id = $1`, [session.id]);
      const { token: newToken, hash: newHash } = newRefreshToken();
      await client.query(
        `INSERT INTO auth_sessions (user_id, refresh_token_hash, user_agent, ip, expires_at)
         VALUES ($1, $2, $3, $4, $5)`,
        [session.user_id, newHash, req.headers["user-agent"] || null, req.ip, refreshExpiry()]
      );
      const u = (await client.query(`SELECT * FROM users WHERE id = $1`, [session.user_id])).rows[0];
      await client.query("COMMIT");

      res.json({ accessToken: signAccessToken(u), refreshToken: newToken });
    } catch (e) {
      await client.query("ROLLBACK"); throw e;
    } finally {
      client.release();
    }
  } catch (e) { next(e); }
});

// POST /auth/logout  { refreshToken }
router.post("/auth/logout", requireAuth, async (req, res, next) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) await query(`UPDATE auth_sessions SET revoked_at = now() WHERE refresh_token_hash = $1`, [sha256(refreshToken)]);
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = { router, publicUser };
