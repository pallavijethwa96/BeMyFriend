# BeMyFriend — Backend API

Node + Express + PostgreSQL service for the BeMyFriend app and website. Implements the **auth flow** (email + phone OTP → JWT access + rotating refresh tokens), **community** (groups, posts, replies, support), the **Aria AI proxy**, and **safety** (crisis resources, reports, blocks).

> Starting implementation — functional, but review and harden before production (see checklist at the bottom). This is a separate server; it does **not** run inside the chat artifact.

## Requirements
- Node.js 18+ (uses the global `fetch`)
- PostgreSQL 13+

## Setup
```bash
# 1. Install dependencies
npm install

# 2. Create the database
createdb bemyfriend

# 3. Configure environment
cp .env.example .env
#   - set DATABASE_URL
#   - set a long random JWT_SECRET
#   - set AI_API_KEY (for Aria) if you want the AI companion to work

# 4. Create the tables + seed data
npm run migrate

# 5. Run
npm run dev      # auto-reload
# or
npm start
```
The API listens on `http://localhost:4000` by default. Health check: `GET /health`.

## Auth flow (quick test)
```bash
# 1) start — sends OTP (in dev the code is returned as devCode)
curl -s localhost:4000/auth/start -H 'content-type: application/json' \
  -d '{"email":"you@example.com","phone":"+919876543210"}'
# -> { "challengeId": "...", "devCode": "123456" }

# 2) verify — returns tokens + user
curl -s localhost:4000/auth/verify -H 'content-type: application/json' \
  -d '{"challengeId":"...","code":"123456"}'
# -> { "accessToken": "...", "refreshToken": "...", "user": {...}, "isNewUser": true }

# 3) authenticated call
curl -s localhost:4000/groups -H 'authorization: Bearer <accessToken>'
```

## Endpoint map
- `POST /auth/start`, `POST /auth/verify`, `POST /auth/refresh`, `POST /auth/logout`
- `GET/PATCH/DELETE /me`, `PATCH /me/onboarding`, `POST /me/consent`, `POST /me/checkins`
- `GET /groups`, `GET /groups/:slug`, `GET /groups/:slug/posts`, `POST /groups/:slug/posts`
- `GET /posts/:id`, `DELETE /posts/:id`, `POST|DELETE /posts/:id/support`, `POST /posts/:id/replies`, `DELETE /replies/:id`
- `GET /aria/conversation`, `POST /aria/messages`, `DELETE /aria/conversation`
- `GET /crisis-resources?country=`, `POST /reports`, `GET|POST /blocks`, `DELETE /blocks/:userId`

See `../BeMyFriend-Technical-Spec.md` for the full reference.

## Project layout
```
db/schema.sql        tables, triggers, seed data
src/config.js        env config
src/db.js            pg pool + query helper
src/auth.js          JWT, OTP, refresh tokens, middleware
src/migrate.js       applies schema.sql
src/index.js         express app, mounts routes
src/routes/auth.js       OTP login + refresh
src/routes/account.js    profile, onboarding, consent, crisis, reports, blocks
src/routes/community.js  groups, posts, replies, support
src/routes/aria.js       AI companion proxy
```

## Before production — harden this
- Send OTPs through real **email + SMS providers** (the code is currently logged in dev). Remove `devCode` from responses.
- Put refresh tokens in **httpOnly+Secure cookies** (web) / secure storage (mobile).
- Add **input validation** (e.g. zod) and stricter rate limits.
- **Encrypt sensitive content at rest**, restrict DB access, and add audit logging.
- Add a **content-moderation** path and the staff moderation endpoints (`/admin/*` from the spec).
- Add automated tests and run migrations through a proper tool (e.g. node-pg-migrate) as the schema evolves.
- Enforce the **minimum age** and consent at sign-up, and add a data-deletion/retention job.
